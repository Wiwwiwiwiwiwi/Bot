"""تست‌های واحد ربات railway-bot — توابع خالص و منطق مسیریابی."""
import json
import os
import re
import subprocess
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import bot  # noqa: E402


# ── UI helpers ──
def test_esc_html():
    assert bot.esc("<b>x</b>") == "&lt;b&gt;x&lt;/b&gt;"
    assert bot.esc("سلام") == "سلام"


def test_bar_bounds():
    assert bot.bar(0) == "▱" * bot.TOTAL_STEPS
    assert bot.bar(bot.TOTAL_STEPS) == "▰" * bot.TOTAL_STEPS
    assert bot.bar(99) == "▰" * bot.TOTAL_STEPS
    assert bot.bar(-3) == "▱" * bot.TOTAL_STEPS


def test_card_structure():
    c = bot.card("عنوان", "بدنه", emoji="✅", footer="پایین")
    assert "عنوان" in c and "بدنه" in c and "پایین" in c
    assert "━" in c


# ── callback_data ──
@pytest.mark.parametrize("name", ["اصلی", "تست ۲", "کانفیگ دوم", "a:b:c", "x'\"<y>", "emoji😀"])
def test_cb_roundtrip(name):
    """roundtrip باید درست باشد (محدودیت ۶۴ بایت با کلید کوتاه حل می‌شود —
    رجوع به test_accounts_kbd_short_keys)."""
    d = bot.cb("acc_switch", name)
    assert bot.uncb(d) == name


def test_accounts_kbd_short_keys():
    user = {"accounts": {"اصلی": {}, "کانفیگ دوم": {}, "تست": {}},
            "active_account": "اصلی"}
    kbd = bot.accounts_kbd(user)
    assert user["cb_names"]["a2"] == "کانفیگ دوم"
    for row in kbd.inline_keyboard:
        for b in row:
            assert len(b.callback_data.encode()) <= 64
            if b.callback_data.startswith(("acc_switch:", "acc_del:")):
                assert "ک" not in b.callback_data  # اسم فارسی نباید توی callback باشد


def test_acc_name_from_key():
    user = {"cb_names": {"a1": "اصلی"}}
    assert bot.acc_name_from_key(user, "a1") == "اصلی"
    assert bot.acc_name_from_key(user, "a9") == "a9"
    assert bot.acc_name_from_key(None, "a1") == "a1"


# ── منو ↔ مسیریابی ──
def test_menu_buttons_match_handle_text():
    src = open(os.path.join(os.path.dirname(__file__), "..", "bot.py")).read()
    buttons = set(re.findall(r'KeyboardButton\("([^"]+)"\)', src))
    matches = set(re.findall(r'if text == "([^"]+)"', src))
    assert buttons == matches, (buttons - matches, matches - buttons)


# ── چند اکانت ──
def test_token_flow_auto_names():
    USERS = {}
    def sim(uid, token):
        user = USERS.get(uid)
        if user is None:
            USERS[uid] = {"accounts": {}, "active_account": ""}
            user = USERS[uid]
        if not user.get("accounts"):
            name = "default"
        else:
            n = len(user["accounts"]) + 1
            name = f"account-{n}"
            while name in user["accounts"]:
                n += 1
                name = f"account-{n}"
        user["accounts"][name] = {"token": token}
        user["active_account"] = name
        return name
    assert sim(1, "T" * 36) == "default"
    assert sim(1, "T" * 36) == "account-2"
    assert sim(1, "T" * 36) == "account-3"
    assert len(USERS[1]["accounts"]) == 3
    assert USERS[1]["active_account"] == "account-3"


# ── بازیافت پروژه (find_or_create_project) ──
def test_find_or_create_project_reuses_incomplete():
    def fake(token, query, variables=None):
        if "projects(workspaceId" in query:
            return {"data": {"projects": {"edges": [
                {"node": {"id": "P_EMPTY", "name": "3xui-multi-region",
                          "createdAt": "2026-08-08T21:34:00Z"}},
                {"node": {"id": "P_FULL", "name": "3xui-multi-region",
                          "createdAt": "2026-08-08T21:18:00Z"}},
            ]}}}
        if "project(id" in query:
            svcs = (["xui-nl", "xui-sg", "xui-us-va", "xui-us-ca"]
                    if variables["id"] == "P_FULL" else [])
            return {"data": {"project": {"services": {
                "edges": [{"node": {"name": n}} for n in svcs]}}}}
        if "projectCreate" in query:
            return {"data": {"projectCreate": {"id": "P_NEW", "name": "xui"}}}
        raise AssertionError(query)
    bot.gql = fake
    assert bot.find_or_create_project("t", "w") == "P_EMPTY"


def test_find_or_create_project_creates_when_full():
    def fake(token, query, variables=None):
        if "projects(workspaceId" in query:
            return {"data": {"projects": {"edges": [
                {"node": {"id": "P_FULL", "name": "3xui-multi-region",
                          "createdAt": "2026-08-08T21:18:00Z"}}]}}}
        if "project(id" in query:
            return {"data": {"project": {"services": {"edges": [
                {"node": {"name": n}} for n in
                ["xui-nl", "xui-sg", "xui-us-va", "xui-us-ca"]]}}}}
        if "projectCreate" in query:
            return {"data": {"projectCreate": {"id": "P_NEW", "name": "xui"}}}
        raise AssertionError(query)
    bot.gql = fake
    assert bot.find_or_create_project("t", "w") == "P_NEW"


# ── بازیافت سرویس (deploy.py) ──
def test_deploy_create_service_reuses():
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "deploy", os.path.join(os.path.dirname(__file__), "..", "scripts", "deploy.py"))
    deploy = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(deploy)

    def fake(query, variables=None):
        if "project(id" in query:
            return {"data": {"project": {"services": {"edges": [
                {"node": {"id": "S_NL", "name": "xui-nl"}},
                {"node": {"id": "S_SG", "name": "xui-sg"}},
            ]}}}}
        if "serviceCreate" in query:
            return {"data": {"serviceCreate": {"id": "S_NEW", "name": variables["input"]["name"]}}}
        raise AssertionError(query)
    deploy.gql = fake
    assert deploy.create_service("P", "xui-nl") == "S_NL"  # بازیافت
    assert deploy.create_service("P", "xui-us-va") == "S_NEW"  # ساخت


# ── چرخش: پارس خروجی ──
def test_proxy_result_regex():
    pat = re.compile(r"PROXY_RESULT:\s*([\w-]+)=([\w.-]+):(\d+)")
    m = pat.search("PROXY_RESULT: xui-nl=monorail.proxy.rlwy.net:443")
    assert m and m.groups() == ("xui-nl", "monorail.proxy.rlwy.net", "443")
    m = pat.search("PROXY_RESULT:xui-sg=turntable.proxy.rlwy.net:16139")
    assert m and m.groups() == ("xui-sg", "turntable.proxy.rlwy.net", "16139")


def test_rebuild_servers_json():
    acc = {"reality_keys": {"pub": "P", "sid": "S"},
           "proxy_map": {"xui-nl": {"host": "monorail.proxy.rlwy.net", "port": 443},
                         "xui-sg": {"host": "turntable.proxy.rlwy.net", "port": 16139}}}
    bot._rebuild_servers_json(acc)
    srv = json.loads(acc["servers_json"])
    assert len(srv) == 2
    assert srv[0]["pbk"] == "P" and srv[0]["sid"] == "S"
    assert srv[0]["host"].endswith("rlwy.net")


# ── تایم‌اوت/توقف چرخش (با اسکریپت فیک) ──
def test_run_rotate_cancel_and_timeout():
    import asyncio
    import tempfile

    with tempfile.TemporaryDirectory() as d:
        with open(os.path.join(d, "rotate-proxies.py"), "w") as f:
            f.write("import time\ntime.sleep(30)\n")
        old = bot.SCRIPT_DIR
        bot.SCRIPT_DIR = d
        os.environ["ROTATE_TIMEOUT"] = "3"
        acc = {"token": "t", "env_id": "e",
               "service_ids": {"xui-nl": "s1"},
               "proxy_map": {"xui-nl": {}}}

        class FakeMsg:
            async def edit_text(self, *a, **kw):
                pass

        async def run():
            lines, _ = await bot.run_script_async("rotate-proxies.py", {}, FakeMsg(),
                                                  "تست", timeout=3, show_tail=False)
            return lines
        lines = asyncio.run(run())
        assert "TIMEOUT" in lines
        bot.SCRIPT_DIR = old


# ── کامپایل همه اسکریپت‌ها ──
def test_py_compile_scripts():
    root = os.path.join(os.path.dirname(__file__), "..")
    files = [os.path.join(root, "bot.py")] + [
        os.path.join(root, "scripts", f) for f in os.listdir(os.path.join(root, "scripts"))
        if f.endswith(".py")
    ]
    for f in files:
        r = subprocess.run([sys.executable, "-m", "py_compile", f],
                           capture_output=True, text=True)
        assert r.returncode == 0, f"{f}: {r.stderr}"


# ── رمزنگاری state (STATE_SECRET) ──
def test_state_encryption_roundtrip():
    """با _CIPHER فعال: ذخیره باید token را ببرد (token_e می‌گذارد) و بارگذاری برگرداند."""
    from cryptography.fernet import Fernet
    bot._CIPHER = Fernet(Fernet.generate_key())
    try:
        users = {
            "123": {
                "active_account": "default",
                "accounts": {"default": {"token": "SECRETTOKEN123"}},
            }
        }
        enc = bot._enc_state(users)
        # روی دیسک نباید توکن خام باشد؛ باید token_e باشد
        acc_enc = enc["123"]["accounts"]["default"]
        assert "token" not in acc_enc
        assert acc_enc["token_e"]
        assert "SECRETTOKEN123" not in json.dumps(enc)

        dec = bot._dec_state(json.loads(json.dumps(enc)))
        assert dec["123"]["accounts"]["default"]["token"] == "SECRETTOKEN123"
    finally:
        bot._CIPHER = None


def test_state_plaintext_when_no_cipher():
    """بدون _CIPHER (STATE_SECRET خالی): رفتار قبلی — متن ساده، بدون token_e."""
    bot._CIPHER = None
    users = {"1": {"accounts": {"d": {"token": "T" * 36}}}}
    enc = bot._enc_state(users)
    # همان دیکشنری (کپی نیست، سراسری می‌ماند) — token حفظ شده
    assert enc["1"]["accounts"]["d"]["token"] == "T" * 36
    assert "token_e" not in enc["1"]["accounts"]["d"]
